# counting PLN > 2024-09-12 2:51pm
https://universe.roboflow.com/counting-pln-polski-zloty/counting-pln

Provided by a Roboflow user
License: CC BY 4.0

